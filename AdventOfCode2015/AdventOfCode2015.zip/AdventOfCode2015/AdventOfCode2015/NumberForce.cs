﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventOfCode2015
{
    class NumberForce
    {
        private int currentNumber;
        private int target;

        public NumberForce(int target)
        {
            this.target = target;
            currentNumber = 0;
        }

        public void start(int startingNumber)
        {
            currentNumber = startingNumber;
        }

        public void feed(int a,int b, char a1, char a2)
        {
            List<string> expressions = new List<string>();
            expressions.Add(currentNumber + "" + a1 + "" + a + "" + a2 + " " + b);
            expressions.Add(currentNumber + "" + a2 + "" + a + "" + a1 + " " + b);
            expressions.Add(currentNumber + "" + a1 + "" + b + "" + a2 + " " + a);
            expressions.Add(currentNumber + "" + a2 + "" + b + "" + a1 + " " + a);
            expressions.Add("(" + currentNumber + "" + a1 + "" + a + ")" + a2 + " " + b);
            expressions.Add("(" + currentNumber + "" + a2 + "" + a + ")" + a1 + " " + b);
            expressions.Add("(" + currentNumber + "" + a1 + "" + b + ")" + a2 + " " + a);
            expressions.Add("(" + currentNumber + "" + a2 + "" + b + ")" + a1 + " " + a);

            DataTable dt = new DataTable();
            int closestIndex = -1, closest = int.MaxValue;
            for(int i = 0; i< expressions.Count;i++){
                try
                {
                    int v = (int) dt.Compute(expressions[i], "");
                    int temp = Math.Abs(v - target);
                    if(temp < closest){
                        closest = temp;
                        closestIndex = i;
                    }
                } catch (Exception e){
                    continue;
                }
            }
            if(closestIndex != -1){
                currentNumber = (int) dt.Compute(expressions[closestIndex], "");
            }
        }

        public bool isSuccessfullForce()
        {
            return target == currentNumber;
        }

        internal int getCurrentNumber()
        {
            return currentNumber;
        }
    }
}
